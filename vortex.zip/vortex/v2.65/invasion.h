#define MONSTERSPAWN_STATUS_WORKING		0 // spawning a wave of monsters
#define MONSTERSPAWN_STATUS_IDLE		1 // waiting for current wave to be killed

#define PLAYERSPAWN_REGEN_FRAMES		800
#define PLAYERSPAWN_REGEN_DELAY			10
#define PLAYERSPAWN_HEALTH				2500

#define INVASION_BONUS_EXP				10000
#define INVASION_BONUS_CREDITS			10000

