#define WEAPON_RUNE			1
#define ABILITY_RUNE		2
#define HEALTH_POTION		3
/*
void ItemClear (items_t *item);
void ItemDebugPrint (items_t *item);
char GetRandomChar (void);
char *GetRandomString (int len);
qboolean G_CanPickUpItem (edict_t *ent);
items_t *G_FindFreeItemSlot (edict_t *ent);
void ItemCopy (items_t *source, items_t *dest);
int GetItemValue (items_t *item);
char *GetItemQualityString (items_t *item);
char *GetItemTypeString (items_t *item);
void PrintItemProperties (edict_t *ent, items_t *item);
void OpenItemHelpMenu (edict_t *ent);
void ShowInventoryMenu (edict_t *ent, int lastline);
void OpenPlayerSelectMenu (edict_t *ent);
void OpenTradeItemSelectMenu (edict_t *ent, int lastline);
void OpenTradeConfirmMenu (edict_t *ent, int lastline);
void OpenTradeConfirmMenu (edict_t *ent, int lastline);
void tradeconfirm_handler (edict_t *ent, int option);
void OpenItemPropertiesMenu (edict_t *ent, items_t *item);
void ItemMenuClose (edict_t *ent);
void EmptyQueue (edict_t *ent);
*/