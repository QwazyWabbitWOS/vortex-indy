/*
#define ITEM_SWORD			1
#define ITEM_SHOTGUN		2
#define ITEM_SSGUN			3
#define ITEM_MGUN			4
#define ITEM_CGUN			5
#define ITEM_GLAUNCHER		6
#define ITEM_RLAUNCHER		7
#define ITEM_HYPERBLASTER	8
#define ITEM_RAILGUN		9
#define ITEM_BFG			10
#define ITEM_HGRENADES		11
#define ITEM_CANNON			12
#define ITEM_BLASTER		13

qboolean Pickup_Rune (edict_t *ent, edict_t *other);
void SpawnRune (edict_t *self, edict_t *attacker, qboolean debug);
void RemoveWeaponRune (edict_t *ent);
void ApplyWeaponRune (edict_t *ent);
void ApplyAbilityRune (edict_t *ent);
void RemoveAbilityRune (edict_t *ent);
char *GetAbilityString (int ability_number);
void rune_getweaponstrings (items_t *item, char *s1, char *s2, char *s3, char *s4);
void PurchaseRandomRune (edict_t *ent);
*/
